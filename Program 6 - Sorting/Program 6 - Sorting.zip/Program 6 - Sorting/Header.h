/*
Bryson May
CS 2420
Program 6 - Sorting

I emailed the professor about having issues with my laptop
which is why this is late.  He hasn't gotten back to me yet,
so if you could ask him if he got my email that would be great. 

*/


#pragma once

using namespace std;

#include <iostream>
#include <fstream>
#include <string>
#include <cassert>
#include <time.h>
#include <stdio.h>
#include <dos.h>