/*
Bryson May
CS 2420
Program 4 - Binary Search Tree
*/

#pragma once

using namespace std;
#include <fstream>
#include <string>
#include <cassert>
#include <iostream>
#include "Tree.h"