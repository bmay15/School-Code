//-----------------------------------------------------------
//Name: Bryson May
//Class: CS 2420
//Assignment: Program 2 - Linked Lists
//-----------------------------------------------------------

#pragma once
using namespace std;

#include <fstream>
#include <string>
#include <cassert>
#include <iostream>
#include "Sing_List.h";
#include "Doub_List.h";

