/*
Bryson May
CS 2420
Program 4 - Binary Search Tree
*/

#pragma once

using namespace std;
#include <fstream>
#include <iostream>
#include <string>
#include <cassert>
#include "Table.h"
