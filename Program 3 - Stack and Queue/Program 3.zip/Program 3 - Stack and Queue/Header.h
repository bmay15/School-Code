/*--------------------------------------------
Bryson May
CS 2420
Program 3 - Stack and Queue

I turned this in literally half an hour after midnight,
I was sooooooo close! Any slack that could be cut would be appreciated :)
*/

#pragma once

using namespace std;

#include <iostream>
#include <fstream>
#include <string>
#include <cassert>
#include "Stack.h"
#include "Queue.h"
#include "Node.h"